package br.com.targettrust.locadora.entidades;

public class Entidade {
	
	private Integer id;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	

}
